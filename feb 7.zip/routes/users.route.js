const userController = require('../controllers/users.controller')
const auth = require('../middlewares/auth')
const passport = require('passport');
<<<<<<< HEAD
const { validate } = require('../middlewares/validator');
=======
const recaptcha = require('../middlewares/recaptcha');
>>>>>>> 6e6755d967f0988deabdd78c2d331a7b26a71ee3

exports.routes = (app) => { 
    const userValidate = validate.bind(null, 'user.schema.json'); // bind user validatorSchema identifier to validate method.
    
    app.get('/users/session-details', passport.authenticate('jwt', {session: false}), userController.getUserSessionDetails);
<<<<<<< HEAD
    app.post('/users/register', userValidate('register'), userController.register);
    app.post('/users/login', userValidate('login'), userController.login);
=======
    app.post('/users/register',recaptcha.Validate, userController.register);
    app.post('/users/login',recaptcha.Validate, userController.login);
>>>>>>> 6e6755d967f0988deabdd78c2d331a7b26a71ee3
    app.put('/users/verify-email', userController.verifyEmail);
    app.post('/users/recaptcha', userController.recaptcha);
}
